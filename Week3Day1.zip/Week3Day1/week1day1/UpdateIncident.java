package week1day1;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class UpdateIncident {

	@Test
	public void update() {
		//Base Uri
		
		RestAssured.baseURI="https://dev200784.service-now.com/api/now/table/";
		
		//Authentication
		
		RestAssured.authentication=RestAssured.basic("admin", "I-Ks*dzGjO63");
		
		//Request Body
		
		RequestSpecification inputRequest = RestAssured.given().contentType("application/json")
		.when()
		.body("{\r\n"
				+ "    \"short_description\": \"Mobile Service\",\r\n"
				+ "    \"description\": \"Mobile charging Problem\"\r\n"
				+ "}");
		
		//Initiate Request
		Response response = inputRequest.put("incident/af5b626d476042100b45d48f016d4318");
		
		response.prettyPrint();
		
		
	}
}
