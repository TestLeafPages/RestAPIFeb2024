package week1day1;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class GetAllWithQP {
	
	@Test
	public void get() {
		//Base Uri
		
		RestAssured.baseURI="https://dev200784.service-now.com/api/now/table/";
		
		//Add Auth
		
		RestAssured.authentication=RestAssured.basic("admin", "I-Ks*dzGjO63");
		
		//Add Query Parameter
		
		RequestSpecification inputRequest = RestAssured.given().queryParam("sysparm_fields", "short_description,description,sys_id");
		
		//Initiate Request
		Response response = inputRequest.get("incident");
		
		response.prettyPrint();
		
	}

}
