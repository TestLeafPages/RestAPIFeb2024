package week1day1;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class DeleteIncident {

	@Test
	public void delete() {
		
		//Base Uri
		
		RestAssured.baseURI="https://dev200784.service-now.com/api/now/table/";
		
		//Authentication
		
		RestAssured.authentication=RestAssured.basic("admin", "I-Ks*dzGjO63");
		
		Response response = RestAssured.delete("incident/af5b626d476042100b45d48f016d4318");
		
		//to get response code
		
		int statusCode = response.getStatusCode();
		
		System.out.println("Delete status code"+statusCode);
		
		
		
		
		
		
		
		
	}
}
