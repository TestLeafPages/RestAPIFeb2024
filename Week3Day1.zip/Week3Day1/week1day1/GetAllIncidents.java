package week1day1;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class GetAllIncidents {
	
	@Test
	public void getAll() {
		
	//Base Uri
		
	RestAssured.baseURI="https://dev200784.service-now.com/api/now/table/";
	
	//Add Auth
	
	RestAssured.authentication=RestAssured.basic("admin", "I-Ks*dzGjO63");
	
	//Initiate Request
	
	Response response = RestAssured.get("incident");
	
	response.prettyPrint();
	
	
	
	
	
	
	
	
		
	}

}
