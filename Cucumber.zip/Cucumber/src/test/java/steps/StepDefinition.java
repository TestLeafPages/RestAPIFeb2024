package steps;

import java.io.File;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class StepDefinition {

	public static Response response;
	public static RequestSpecification inputRequest;
	@Given("Set the endpoint")
	public void setEndpoint() {
		RestAssured.baseURI="https://dev200784.service-now.com/api/now/table/";
	}
	
	@And("set the Auth")
	public void setAuth() {
	RestAssured.authentication=RestAssured.basic("admin", "I-Ks*dzGjO63");
	}
	
	@When("get incidents")
	public void getIncidents() {
	response=RestAssured.get("incident");
	}
	
	@Then("validate response code as {int}")
	public void validateStatusCode(int responseCode) {
		response.then().assertThat().statusCode(responseCode);
	}
	
	@When("create incident with string body {string}")
	public void createIncidentBody(String body) {
     inputRequest = RestAssured.given().contentType("application/json").when()
		.body(body);
		 response = inputRequest.post("incident");
		 response.prettyPrint();
	}
	@When("create incident with file {string}")
	public void createIncidentFile(String fileName) {
		
	File file=new File("./src/test/resources/"+fileName);
	inputRequest=RestAssured.given().contentType("application/json")
	.when().body(file);
	response=inputRequest.post("incident");
		
	}
	
	
}
